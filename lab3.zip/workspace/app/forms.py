from flask_wtf import FlaskForm
from wtforms import StringField, TextField, SubmitField, TextAreaField 
from wtforms.validators import DataRequired
import django
#from django import forms
from forms import forms
import random
from flask import Flask


DEBUG = True
app = Flask(__name__)
app.config.from_object(__name__)

for x in range(1):
    app.config['secret_key'] = random.randint(1000000000,100000000000)

class ContactForm(forms.Form):
    def getForm(self,message,request,subject,fname,email):
        form=ContactForm(request.forms)
        self.fname= StringField(fname,validators=[DataRequired()])
        self.email=TextField(email,validators=[DataRequired()])
        self.message=TextAreaField(message,validators=[DataRequired()])
    
    
    print (forms.errors)
    
    if forms.validate():
        flash('Hey '+name+'!')
    else:
        flash('All form fields are required')

    ##def __init__(fname,email,subject,message):
       
    @app.route('/submit', methods=['GET','POST'])
    def submit():
        form = MyForm()
        if form.validate_on_submit():
            return redirect('/success')
    
        return render_template('conatct.html', form=form)
    
    if __name__=="__main__":    
        app.run()
    