# INFO3180 - Lab 3
This is the starter code for Lab 3

Remember to always create a virtual environment and install the packages in your requirements file

```
$ python -m venv venv (you may need to use python3 or python3.5 [on Cloud9] instead)
$ source venv/bin/activate (or .\venv\Scripts\activate on Windows)
$ pip install -r requirements.txt 
$ python run.py
```
